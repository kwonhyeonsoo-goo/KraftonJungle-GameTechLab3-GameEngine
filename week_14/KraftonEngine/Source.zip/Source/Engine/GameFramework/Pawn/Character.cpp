#include "GameFramework/Pawn/Character.h"

#include "Component/Shape/CapsuleComponent.h"
#include "Component/Input/InputComponent.h"
#include "Component/Movement/CharacterMovementComponent.h"
#include "Component/Primitive/SkeletalMeshComponent.h"
#include "Math/Rotator.h"
#include "Mesh/MeshManager.h"
#include "Runtime/Engine.h"

#include <algorithm>
void ACharacter::InitDefaultComponents(const FString& SkeletalMeshFileName)
{
	// 1) Capsule — Root. CharacterMovement 의 UpdatedComponent 가 이걸 가리킴.
	CapsuleComponent = AddComponent<UCapsuleComponent>();
	SetRootComponent(CapsuleComponent);

	// 물리 시뮬레이션(중력/반발)은 CharacterMovement 가 직접 처리하므로 끄되, trigger volume
	// 등과의 overlap 이벤트는 받아야 한다. PhysX 백엔드는 static-static pair 를 생성하지 않아
	// simulate=false 인 static 바디로는 static trigger 와 overlap 이 발화되지 않으므로 kinematic 으로 등록
	// (kinematic↔static pair → setKinematicTarget 으로 위치 추적 + trigger 콜백 수신).
	// ※ overlap 을 받으려면 CollisionEnabled 가 QueryOnly/QueryAndPhysics 여야 물리 씬에 등록됨.
	CapsuleComponent->SetKinematic(true);

	// 2) SkeletalMesh — Capsule 의 자식.
	Mesh = AddComponent<USkeletalMeshComponent>();
	Mesh->AttachToComponent(CapsuleComponent);

	ID3D11Device* Device = GEngine->GetRenderer().GetFD3DDevice().GetDevice();
	if (!SkeletalMeshFileName.empty())
	{
		USkeletalMesh* Asset = FMeshManager::LoadSkeletalMesh(SkeletalMeshFileName, Device);
		Mesh->SetSkeletalMesh(Asset);
	}

	// 3) CharacterMovement — non-scene. UpdatedComponent = Capsule.
	CharacterMovement = AddComponent<UCharacterMovementComponent>();
	CharacterMovement->SetUpdatedComponent(CapsuleComponent);
}

void ACharacter::PostDuplicate()
{
	Super::PostDuplicate();
	// 컴포넌트 트리 재발견 — Duplicate 후 멤버 포인터 복원.
	CapsuleComponent  = Cast<UCapsuleComponent>(GetRootComponent());
	Mesh              = GetComponentByClass<USkeletalMeshComponent>();
	CharacterMovement = GetComponentByClass<UCharacterMovementComponent>();
}

void ACharacter::AddMovementInput(const FVector& WorldDirection, float ScaleValue)
{
	if (CharacterMovement)
	{
		CharacterMovement->AddInputVector(WorldDirection, ScaleValue);
	}
}

void ACharacter::Jump()
{
	if (CharacterMovement)
	{
		CharacterMovement->Jump();
	}
}

void ACharacter::SetupInputComponent()
{
	Super::SetupInputComponent();

	if (!InputComponent) return;

	if (bAutoInputWASD)
	{
		// Capsule (RootComponent) 기준 — yaw 회전이 곧 캐릭터 facing. mouse look 이 yaw 만
		// 변경 → forward/right vector 가 자동 회전 → WASD 가 "카메라 보는 방향" 으로 이동.
		InputComponent->AddAxisMapping("MoveForward", 'W',  1.0f);
		InputComponent->AddAxisMapping("MoveForward", 'S', -1.0f);
		InputComponent->AddAxisMapping("MoveRight",   'D',  1.0f);
		InputComponent->AddAxisMapping("MoveRight",   'A', -1.0f);

		// WASD 의 forward/right 는 ControlRotation.Yaw 기준 — capsule rotation 과 무관.
		// "카메라가 보는 방향" (yaw 만, pitch 무시) 으로 이동.
		InputComponent->BindAxis("MoveForward", [this](float Value)
		{
			if (Value == 0.0f) return;
			const FRotator YawOnly(0.0f, GetControlRotation().Yaw, 0.0f);
			AddMovementInput(YawOnly.GetForwardVector(), Value);
		});
		InputComponent->BindAxis("MoveRight", [this](float Value)
		{
			if (Value == 0.0f) return;
			const FRotator YawOnly(0.0f, GetControlRotation().Yaw, 0.0f);
			AddMovementInput(YawOnly.GetRightVector(), Value);
		});

		// Space = Jump. Walking 중에만 effective (CharacterMovement::Jump 가 guard).
		InputComponent->AddActionMapping("Jump", 0x20);
		InputComponent->BindAction("Jump", EInputEvent::Pressed, [this]()
		{
			Jump();
		});
	}

	if (bAutoInputMouseLook)
	{
		InputComponent->AddMouseAxisMapping("Turn", EInputAxisSourceType::MouseX, MouseSensitivity);
		InputComponent->AddMouseAxisMapping("LookUp", EInputAxisSourceType::MouseY, MouseSensitivity);

		InputComponent->BindAxis("Turn", [this](float Value)
		{
			if (Value == 0.0f) return;
			FRotator Rot = GetControlRotation();
			Rot.Yaw += Value;
			SetControlRotation(Rot);
		});

		InputComponent->BindAxis("LookUp", [this](float Value)
		{
			if (Value == 0.0f) return;
			FRotator Rot = GetControlRotation();
			Rot.Pitch += Value;
			Rot.Pitch = std::clamp(Rot.Pitch, MinCameraPitch, MaxCameraPitch);
			SetControlRotation(Rot);
		});
	}
}

void ACharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// 같은 frame 안 ControlRotation 변경을 capsule (RootComponent) 에 즉시 반영 — 1 frame 지연 없음.
	// 옵션 충돌 가드:
	//   1) bOrientRotationToMovement = true → yaw 는 Movement::PhysOrientToMovement 가 처리.
	//   2) 직전 frame 에 root motion 이 yaw 를 적용했다 → 이번 frame 도 root motion 이 yaw 를
	//      이어받을 가능성이 큼. Character 가 control yaw 로 덮으면 root motion 회전이 즉시
	//      뒤집혀 토글링 됨 (turn-in-place / strafe anim 의 시각 손상). Movement 측에 양보.
	// 두 경우 모두 pitch/roll 만 apply, yaw 는 movement 에 양보.
	if (CapsuleComponent)
	{
		const bool bMovementHandlesYaw = CharacterMovement &&
			(CharacterMovement->bOrientRotationToMovement ||
			 CharacterMovement->HasYawDrivenByRootMotion());

		FRotator R = CapsuleComponent->GetRelativeRotation();
		bool bChanged = false;
		if (bUseControllerRotationYaw && !bMovementHandlesYaw)
		{
			R.Yaw   = ControlRotation.Yaw;
			bChanged = true;
		}
		if (bUseControllerRotationPitch)
		{
			R.Pitch = ControlRotation.Pitch;
			bChanged = true;
		}
		if (bUseControllerRotationRoll)
		{
			R.Roll  = ControlRotation.Roll;
			bChanged = true;
		}
		if (bChanged) CapsuleComponent->SetRelativeRotation(R);
	}
}
